import * as cdk from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';
import { Construct } from 'constructs';

export class EksClusterRoleStack extends cdk.Stack {
  public readonly role: iam.Role;

  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // Create the EKS Cluster Role
    this.role = new iam.Role(this, 'EksClusterRole', {
      roleName: 'prod-sre-eks-cluster-role',
      assumedBy: new iam.ServicePrincipal('eks.amazonaws.com'),
    });

    // Add managed policies
    this.role.addManagedPolicy(
      iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSClusterPolicy')
    );
    this.role.addManagedPolicy(
      iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSVPCResourceController')
    );

    // Create named inline policy
    new iam.Policy(this, 'GetCloudwatchMetricsPolicy', {
      policyName: 'GetCloudwatchMetrics-for-EKS',
      roles: [this.role],
      statements: [
        new iam.PolicyStatement({
          effect: iam.Effect.ALLOW,
          actions: ['cloudwatch:GetMetricData', 'cloudwatch:ListMetrics'],
          resources: ['*'],
        }),
      ],
    });

    // Output the role ARN
    new cdk.CfnOutput(this, 'EksClusterRoleArn', {
      value: this.role.roleArn,
    });
  }
}
