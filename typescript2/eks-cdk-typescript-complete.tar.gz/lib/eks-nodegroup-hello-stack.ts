import * as cdk from 'aws-cdk-lib';
import * as eks from 'aws-cdk-lib/aws-eks';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
import { EksVpcCdkStack } from './eks-vpc-cdk-stack';
import { EksClusterStack } from './eks-cluster-stack';
import { EksLaunchTemplateStack } from './eks-launch-template-stack';

export class EksNodeGroupHelloStack extends cdk.Stack {
  public readonly nodeGroup: eks.CfnNodegroup;
  public readonly helloSg: ec2.SecurityGroup;

  constructor(
    scope: Construct,
    id: string,
    vpcStack: EksVpcCdkStack,
    eksClusterStack: EksClusterStack,
    launchTemplateStack: EksLaunchTemplateStack,
    props?: cdk.StackProps
  ) {
    super(scope, id, props);

    // Get the EKS cluster reference
    const cluster = eksClusterStack.cluster;

    // Get the launch template ID (reusing the same launch template)
    const launchTemplateId = launchTemplateStack.launchTemplate.ref;

    // Get the private subnet IDs
    const privateSubnetIds = vpcStack.privateSubnets.map((subnet) => subnet.ref);

    // Import VPC for security group creation
    const vpcCfn = vpcStack.vpc;
    const vpc = ec2.Vpc.fromVpcAttributes(this, 'ImportedVpc', {
      vpcId: vpcCfn.ref,
      availabilityZones: ['us-east-1a', 'us-east-1b', 'us-east-1c'],
      vpcCidrBlock: '192.168.0.0/16',
    });

    // Create a dedicated security group for prod-hello node group
    this.helloSg = new ec2.SecurityGroup(this, 'HelloNodeGroupSecurityGroup', {
      vpc: vpc,
      securityGroupName: 'prod-hello-ng-sg',
      description: 'Security group for prod-hello node group',
      allowAllOutbound: true,
    });

    // Add ingress rules for the security group
    this.helloSg.addIngressRule(
      ec2.Peer.ipv4('192.168.0.0/16'),
      ec2.Port.tcp(80),
      'Allow HTTP from VPC'
    );

    this.helloSg.addIngressRule(
      ec2.Peer.ipv4('192.168.0.0/16'),
      ec2.Port.allTraffic(),
      'Allow all traffic from VPC'
    );

    // Get the EKS NodeGroup Role ARN
    const eksNodegroupRoleName = 'prod-sre-workernode-role';
    const eksNodegroupRoleArn = `arn:${cdk.Stack.of(this).partition}:iam::${
      cdk.Stack.of(this).account
    }:role/${eksNodegroupRoleName}`;

    // Look up the IAM Role using the constructed ARN
    const eksNodegroupRole = iam.Role.fromRoleArn(
      this,
      'EksNodeGroupRoleLookup',
      eksNodegroupRoleArn,
      {
        mutable: false,
      }
    );

    // Create the EKS Node Group for prod-hello
    this.nodeGroup = new eks.CfnNodegroup(this, 'ProdHelloNodeGroup', {
      clusterName: cluster.name!,
      nodeRole: eksNodegroupRole.roleArn,
      nodegroupName: 'prod-hello-ng',
      subnets: privateSubnetIds,
      launchTemplate: {
        id: launchTemplateId,
        version: '$Latest',
      },
      scalingConfig: {
        desiredSize: 1,
        minSize: 1,
        maxSize: 1,
      },
      capacityType: 'ON_DEMAND',
      amiType: 'AL2023_x86_64_STANDARD',
      tags: {
        Environment: 'prod',
        System: 'prod-eks',
        Component: 'prod-eks-hello',
        NodeGroup: 'prod-hello-ng',
      },
    });

    // Outputs
    new cdk.CfnOutput(this, 'NodeGroupName', {
      value: this.nodeGroup.nodegroupName!,
      description: 'EKS Node Group Name for prod-hello',
    });

    new cdk.CfnOutput(this, 'NodeGroupArn', {
      value: this.nodeGroup.attrArn,
      description: 'EKS Node Group ARN for prod-hello',
    });

    new cdk.CfnOutput(this, 'HelloSecurityGroupId', {
      value: this.helloSg.securityGroupId,
      description: 'Security Group ID for prod-hello node group',
    });

    new cdk.CfnOutput(this, 'UsedLaunchTemplateId', {
      value: launchTemplateId,
      description: 'Launch Template ID used by prod-hello node group',
    });
  }
}
