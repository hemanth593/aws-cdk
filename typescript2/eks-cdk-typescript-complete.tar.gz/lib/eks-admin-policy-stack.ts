import * as cdk from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';
import { Construct } from 'constructs';

export class EksAdminPolicyStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // Look up the existing devops-admin role
    const devopsAdminRole = iam.Role.fromRoleName(
      this,
      'DevopsAdminRole',
      'devops-admins'
    );

    // Create the AdminRoleEKSClusterPolicy and attach it to devops-admin role
    const adminEksPolicy = new iam.Policy(this, 'AdminRoleEKSClusterPolicy', {
      policyName: 'AdminRoleEKSClusterPolicy',
      roles: [devopsAdminRole],
      statements: [
        new iam.PolicyStatement({
          sid: 'EKSAdminAccessPolicy2',
          effect: iam.Effect.ALLOW,
          actions: ['eks:*'],
          resources: ['*'],
        }),
      ],
    });

    // Output the policy name for reference
    new cdk.CfnOutput(this, 'AdminEKSPolicyName', {
      value: adminEksPolicy.policyName,
      description: 'Name of the AdminRoleEKSClusterPolicy',
    });

    // Output confirmation that policy was attached to devops-admin role
    new cdk.CfnOutput(this, 'PolicyAttachedToRole', {
      value: `AdminRoleEKSClusterPolicy attached to ${devopsAdminRole.roleName}`,
      description: 'Confirmation of policy attachment',
    });
  }
}
