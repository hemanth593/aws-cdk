import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';

export class EksVpcCdkStack extends cdk.Stack {
  public readonly vpc: ec2.CfnVPC;
  public readonly publicSubnets: ec2.CfnSubnet[];
  public readonly privateSubnets: ec2.CfnSubnet[];

  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // === VPC ===
    this.vpc = new ec2.CfnVPC(this, 'EksVpc', {
      cidrBlock: '192.168.0.0/16',
      tags: [{ key: 'Name', value: 'eks-vpc' }],
    });

    // === Internet Gateway ===
    const igw = new ec2.CfnInternetGateway(this, 'InternetGateway', {
      tags: [{ key: 'Name', value: 'eks-igw' }],
    });

    new ec2.CfnVPCGatewayAttachment(this, 'VpcIgwAttachment', {
      vpcId: this.vpc.ref,
      internetGatewayId: igw.ref,
    });

    // === Public Subnets ===
    const publicA = new ec2.CfnSubnet(this, 'PublicSubnetA', {
      vpcId: this.vpc.ref,
      cidrBlock: '192.168.0.0/20',
      availabilityZone: 'us-east-1a',
      mapPublicIpOnLaunch: true,
      tags: [{ key: 'Name', value: 'prod-eks-subnet-public-us-east-1a' }],
    });

    const publicB = new ec2.CfnSubnet(this, 'PublicSubnetB', {
      vpcId: this.vpc.ref,
      cidrBlock: '192.168.16.0/20',
      availabilityZone: 'us-east-1b',
      mapPublicIpOnLaunch: true,
      tags: [{ key: 'Name', value: 'prod-eks-subnet-public-us-east-1b' }],
    });

    const publicC = new ec2.CfnSubnet(this, 'PublicSubnetC', {
      vpcId: this.vpc.ref,
      cidrBlock: '192.168.32.0/20',
      availabilityZone: 'us-east-1c',
      mapPublicIpOnLaunch: true,
      tags: [{ key: 'Name', value: 'prod-eks-subnet-public-us-east-1c' }],
    });

    // === Private Subnets ===
    const privateA = new ec2.CfnSubnet(this, 'PrivateSubnetA', {
      vpcId: this.vpc.ref,
      cidrBlock: '192.168.48.0/20',
      availabilityZone: 'us-east-1a',
      mapPublicIpOnLaunch: false,
      tags: [{ key: 'Name', value: 'prod-eks-subnet-private-us-east-1a' }],
    });

    const privateB = new ec2.CfnSubnet(this, 'PrivateSubnetB', {
      vpcId: this.vpc.ref,
      cidrBlock: '192.168.64.0/20',
      availabilityZone: 'us-east-1b',
      mapPublicIpOnLaunch: false,
      tags: [{ key: 'Name', value: 'prod-eks-subnet-private-us-east-1b' }],
    });

    const privateC = new ec2.CfnSubnet(this, 'PrivateSubnetC', {
      vpcId: this.vpc.ref,
      cidrBlock: '192.168.80.0/20',
      availabilityZone: 'us-east-1c',
      mapPublicIpOnLaunch: false,
      tags: [{ key: 'Name', value: 'prod-eks-subnet-private-us-east-1c' }],
    });

    // === Public Route Table (1 for all public subnets) ===
    const publicRt = new ec2.CfnRouteTable(this, 'PublicRouteTable', {
      vpcId: this.vpc.ref,
      tags: [{ key: 'Name', value: 'eks-public-rt' }],
    });

    new ec2.CfnRoute(this, 'PublicDefaultRoute', {
      routeTableId: publicRt.ref,
      destinationCidrBlock: '0.0.0.0/0',
      gatewayId: igw.ref,
    });

    [publicA, publicB, publicC].forEach((subnet) => {
      new ec2.CfnSubnetRouteTableAssociation(this, `${subnet.node.id}Assoc`, {
        subnetId: subnet.ref,
        routeTableId: publicRt.ref,
      });
    });

    // === NAT Gateway (1 in Public Subnet A) ===
    const eipNat = new ec2.CfnEIP(this, 'NatEip', {
      domain: 'vpc',
    });

    const natGw = new ec2.CfnNatGateway(this, 'NatGateway', {
      subnetId: publicA.ref,
      allocationId: eipNat.attrAllocationId,
      tags: [{ key: 'Name', value: 'eks-natgw' }],
    });

    // === Private Route Table (1 for all private subnets) ===
    const privateRt = new ec2.CfnRouteTable(this, 'PrivateRouteTable', {
      vpcId: this.vpc.ref,
      tags: [{ key: 'Name', value: 'eks-private-rt' }],
    });

    new ec2.CfnRoute(this, 'PrivateDefaultRoute', {
      routeTableId: privateRt.ref,
      destinationCidrBlock: '0.0.0.0/0',
      natGatewayId: natGw.ref,
    });

    [privateA, privateB, privateC].forEach((subnet) => {
      new ec2.CfnSubnetRouteTableAssociation(this, `${subnet.node.id}Assoc`, {
        subnetId: subnet.ref,
        routeTableId: privateRt.ref,
      });
    });

    // Store subnets for reference
    this.publicSubnets = [publicA, publicB, publicC];
    this.privateSubnets = [privateA, privateB, privateC];

    // === Outputs ===
    new cdk.CfnOutput(this, 'VpcId', { value: this.vpc.ref });
    new cdk.CfnOutput(this, 'VpcCidr', { value: '192.168.0.0/16' });
  }
}
