import * as cdk from 'aws-cdk-lib';
import * as eks from 'aws-cdk-lib/aws-eks';
import * as iam from 'aws-cdk-lib/aws-iam';
import { Construct } from 'constructs';
import { EksVpcCdkStack } from './eks-vpc-cdk-stack';
import { EksClusterStack } from './eks-cluster-stack';
import { EksLaunchTemplateStack } from './eks-launch-template-stack';

export class EksNodeGroupSchedulerStack extends cdk.Stack {
  public readonly nodeGroup: eks.CfnNodegroup;

  constructor(
    scope: Construct,
    id: string,
    vpcStack: EksVpcCdkStack,
    eksClusterStack: EksClusterStack,
    launchTemplateStack: EksLaunchTemplateStack,
    props?: cdk.StackProps
  ) {
    super(scope, id, props);

    // Get the EKS cluster reference
    const cluster = eksClusterStack.cluster;

    // Get the launch template ID
    const launchTemplateId = launchTemplateStack.launchTemplate.ref;

    // Get the private subnet IDs
    const privateSubnetIds = vpcStack.privateSubnets.map((subnet) => subnet.ref);

    // Get the EKS NodeGroup Role ARN
    const eksNodegroupRoleName = 'prod-sre-workernode-role';
    const eksNodegroupRoleArn = `arn:${cdk.Stack.of(this).partition}:iam::${
      cdk.Stack.of(this).account
    }:role/${eksNodegroupRoleName}`;

    // Look up the IAM Role using the constructed ARN
    const eksNodegroupRole = iam.Role.fromRoleArn(
      this,
      'EksNodeGroupRoleLookup',
      eksNodegroupRoleArn,
      {
        mutable: false,
      }
    );

    // Create the EKS Node Group
    this.nodeGroup = new eks.CfnNodegroup(this, 'ProdSchedulerNodeGroup', {
      clusterName: cluster.name!,
      nodeRole: eksNodegroupRole.roleArn,
      nodegroupName: 'prod-scheduler-v2',
      subnets: privateSubnetIds,
      launchTemplate: {
        id: launchTemplateId,
        version: '$Latest',
      },
      scalingConfig: {
        desiredSize: 2,
        minSize: 1,
        maxSize: 2,
      },
      capacityType: 'ON_DEMAND',
      amiType: 'AL2023_x86_64_STANDARD',
      tags: {
        Environment: 'prod',
        System: 'prod-eks',
        Component: 'prod-eks-scheduler',
        NodeGroup: 'prod-scheduler-v2',
      },
    });

    // Outputs
    new cdk.CfnOutput(this, 'NodeGroupName', {
      value: this.nodeGroup.nodegroupName!,
      description: 'EKS Node Group Name',
    });

    new cdk.CfnOutput(this, 'NodeGroupArn', {
      value: this.nodeGroup.attrArn,
      description: 'EKS Node Group ARN',
    });

    new cdk.CfnOutput(this, 'NodeGroupClusterName', {
      value: this.nodeGroup.clusterName!,
      description: 'EKS Cluster Name associated with this node group',
    });

    new cdk.CfnOutput(this, 'UsedLaunchTemplateId', {
      value: launchTemplateId,
      description: 'Launch Template ID used by this node group',
    });

    new cdk.CfnOutput(this, 'UsedPrivateSubnets', {
      value: privateSubnetIds.join(','),
      description: 'Private subnet IDs used by this node group',
    });
  }
}
