import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
import { EksClusterStack } from './eks-cluster-stack';

export class EksLaunchTemplateStack extends cdk.Stack {
  public readonly launchTemplate: ec2.CfnLaunchTemplate;

  constructor(
    scope: Construct,
    id: string,
    eksClusterStack: EksClusterStack,
    props?: cdk.StackProps
  ) {
    super(scope, id, props);

    // Get the primary security group ID from the EKS cluster
    const primarySgId = eksClusterStack.primarySecurityGroupId;

    // Define the key pair name (change this to your actual key pair name)
    const keyPairName = 'prod-eks-sre';

    // User data script for EKS worker nodes
    const userDataScript = `#!/bin/bash
Content-Type: multipart/mixed; boundary="==BOUNDARY=="

--==BOUNDARY==
Content-Type: text/x-shellscript; charset="us-ascii"

# Copyright (C) 2025 Hemanth Pagidimarri <pagidh@amazon.com>
# This file is free software; as a special exception the author gives
# unlimited permission to copy and/or distribute it, with or without
# modifications, as long as this notice is preserved.

INSTANCE_ID=\`curl -sL http://169.254.169.254/latest/meta-data/instance-id\`
REGION=\`curl -sL http://169.254.169.254/latest/meta-data/placement/region\`
PREFIX="prod-eks-scheduler"
TIMESTAMP=$(($(date +"%s%N")/1000000))
SET_HOSTNAME="$PREFIX-$TIMESTAMP"

aws ec2 create-tags --region $REGION --resources $INSTANCE_ID --tags "Key"="Name",Value="$SET_HOSTNAME"

--==BOUNDARY==--
`;

    // Encode user data to base64
    const userDataEncoded = cdk.Fn.base64(userDataScript);

    // Create the launch template
    this.launchTemplate = new ec2.CfnLaunchTemplate(
      this,
      'ProdSchedulerLaunchTemplate',
      {
        launchTemplateName: 'prod-scheduler-v2-lt',
        launchTemplateData: {
          keyName: keyPairName,
          instanceType: 't3a.xlarge',
          userData: userDataEncoded,
          metadataOptions: {
            httpEndpoint: 'enabled',
            instanceMetadataTags: 'enabled',
          },
          tagSpecifications: [
            {
              resourceType: 'instance',
              tags: [
                { key: 'Environment', value: 'prod' },
                { key: 'System', value: 'prod-eks' },
                { key: 'Component', value: 'prod-eks-scheduler' },
              ],
            },
          ],
          networkInterfaces: [
            {
              deviceIndex: 0,
              groups: [primarySgId],
            },
          ],
          blockDeviceMappings: [
            {
              deviceName: '/dev/xvda',
              ebs: {
                deleteOnTermination: true,
                iops: 3000,
                volumeSize: 70,
                volumeType: 'gp3',
                throughput: 125,
              },
            },
          ],
        },
      }
    );

    // Outputs
    new cdk.CfnOutput(this, 'LaunchTemplateId', {
      value: this.launchTemplate.ref,
      description: 'Launch Template ID for EKS node group',
    });

    new cdk.CfnOutput(this, 'LaunchTemplateName', {
      value: this.launchTemplate.launchTemplateName!,
      description: 'Launch Template Name',
    });

    new cdk.CfnOutput(this, 'UsedSecurityGroupId', {
      value: primarySgId,
      description:
        'Primary security group ID from EKS cluster used in launch template',
    });
  }
}
