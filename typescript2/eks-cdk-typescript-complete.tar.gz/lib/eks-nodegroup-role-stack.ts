import * as cdk from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';
import { Construct } from 'constructs';

export class EksNodeGroupRoleStack extends cdk.Stack {
  public readonly role: iam.Role;

  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // Create the EKS Node Group Role
    this.role = new iam.Role(this, 'EksNodeGroupRole', {
      roleName: 'prod-sre-workernode-role',
      assumedBy: new iam.ServicePrincipal('ec2.amazonaws.com'),
    });

    // Add managed policies
    this.role.addManagedPolicy(
      iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEC2ContainerRegistryReadOnly')
    );
    this.role.addManagedPolicy(
      iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKS_CNI_Policy')
    );
    this.role.addManagedPolicy(
      iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSWorkerNodePolicy')
    );
    this.role.addManagedPolicy(
      iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonSSMManagedInstanceCore')
    );
    this.role.addManagedPolicy(
      iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonSSMPatchAssociation')
    );

    // First inline policy for WAF
    new iam.Policy(this, 'AllowWAFpolicy', {
      policyName: 'AllowWAF',
      roles: [this.role],
      statements: [
        new iam.PolicyStatement({
          effect: iam.Effect.ALLOW,
          actions: [
            'wafv2:AssociateWebACL',
            'wafv2:DisassociateWebACL',
            'wafv2:GetWebACL',
          ],
          resources: ['*'],
        }),
      ],
    });

    // Second inline policy for EC2 Tags
    new iam.Policy(this, 'EC2TagsPolicy', {
      policyName: 'EC2Tags',
      roles: [this.role],
      statements: [
        new iam.PolicyStatement({
          effect: iam.Effect.ALLOW,
          actions: [
            'ec2:DescribeInstances',
            'ec2:CreateTags',
            'ec2:DescribeTags',
          ],
          resources: ['*'],
        }),
      ],
    });

    // Third inline policy for GetCW metrics
    new iam.Policy(this, 'GetCloudwatchMetricsPolicy', {
      policyName: 'GetCloudwatchMetrics-for-EKS',
      roles: [this.role],
      statements: [
        new iam.PolicyStatement({
          effect: iam.Effect.ALLOW,
          actions: ['cloudwatch:GetMetricData', 'cloudwatch:ListMetrics'],
          resources: ['*'],
        }),
      ],
    });

    // Single output for the role ARN
    new cdk.CfnOutput(this, 'EksNodeGroupRoleArn', {
      value: this.role.roleArn,
    });
  }
}
