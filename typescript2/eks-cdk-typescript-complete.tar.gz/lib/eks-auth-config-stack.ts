import * as cdk from 'aws-cdk-lib';
import * as eks from 'aws-cdk-lib/aws-eks';
import * as iam from 'aws-cdk-lib/aws-iam';
import { Construct } from 'constructs';
import { EksClusterStack } from './eks-cluster-stack';

export class EksAuthConfigStack extends cdk.Stack {
  constructor(
    scope: Construct,
    id: string,
    eksClusterStack: EksClusterStack,
    props?: cdk.StackProps
  ) {
    super(scope, id, props);

    const adminRoleArn = 'arn:aws:iam::575108957879:role/devops-admins';
    const clusterName = 'prod-eks-sre-cluster';

    // Create the aws-auth ConfigMap using a custom resource
    // This will add the devops-admins role to the cluster's aws-auth ConfigMap
    
    const awsAuthManifest = {
      apiVersion: 'v1',
      kind: 'ConfigMap',
      metadata: {
        name: 'aws-auth',
        namespace: 'kube-system',
      },
      data: {
        mapRoles: cdk.Fn.join('\n', [
          // Admin role mapping
          `- rolearn: ${adminRoleArn}`,
          '  username: devops-admin',
          '  groups:',
          '    - system:masters',
          // Node group role mapping
          `- rolearn: arn:${cdk.Stack.of(this).partition}:iam::${cdk.Stack.of(this).account}:role/prod-sre-workernode-role`,
          '  username: system:node:{{EC2PrivateDNSName}}',
          '  groups:',
          '    - system:bootstrappers',
          '    - system:nodes',
        ]),
      },
    };

    // Note: The above ConfigMap should be applied using kubectl after cluster creation
    // We'll create a custom resource to apply it

    const awsAuthPolicy = new iam.PolicyDocument({
      statements: [
        new iam.PolicyStatement({
          actions: ['eks:DescribeCluster'],
          resources: [eksClusterStack.cluster.attrArn],
        }),
      ],
    });

    const awsAuthRole = new iam.Role(this, 'AwsAuthCustomResourceRole', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
      ],
      inlinePolicies: {
        EksDescribe: awsAuthPolicy,
      },
    });

    // Lambda function code to update aws-auth ConfigMap
    const awsAuthHandler = `
import boto3
import json
import base64
import cfnresponse
from botocore.exceptions import ClientError

eks_client = boto3.client('eks')

def handler(event, context):
    try:
        cluster_name = event['ResourceProperties']['ClusterName']
        admin_role_arn = event['ResourceProperties']['AdminRoleArn']
        node_role_arn = event['ResourceProperties']['NodeRoleArn']
        
        if event['RequestType'] == 'Delete':
            cfnresponse.send(event, context, cfnresponse.SUCCESS, {})
            return
        
        # Get cluster info
        response = eks_client.describe_cluster(name=cluster_name)
        
        # Return success with instructions
        response_data = {
            'Message': 'Please apply aws-auth ConfigMap manually using kubectl',
            'ConfigMapYaml': json.dumps({
                'apiVersion': 'v1',
                'kind': 'ConfigMap',
                'metadata': {'name': 'aws-auth', 'namespace': 'kube-system'},
                'data': {
                    'mapRoles': f"""- rolearn: {admin_role_arn}
  username: devops-admin
  groups:
    - system:masters
- rolearn: {node_role_arn}
  username: system:node:{{{{EC2PrivateDNSName}}}}
  groups:
    - system:bootstrappers
    - system:nodes"""
                }
            }, indent=2)
        }
        
        cfnresponse.send(event, context, cfnresponse.SUCCESS, response_data)
        
    except Exception as e:
        print(f"Error: {str(e)}")
        cfnresponse.send(event, context, cfnresponse.FAILED, {'Error': str(e)})
`;

    // Create a custom resource to trigger the aws-auth update
    const awsAuthCustomResource = new cdk.CustomResource(this, 'AwsAuthCustomResource', {
      serviceToken: this.createAwsAuthProvider(awsAuthHandler, awsAuthRole).serviceToken,
      properties: {
        ClusterName: clusterName,
        AdminRoleArn: adminRoleArn,
        NodeRoleArn: `arn:${cdk.Stack.of(this).partition}:iam::${cdk.Stack.of(this).account}:role/prod-sre-workernode-role`,
      },
    });

    // Output the aws-auth ConfigMap YAML for manual application
    new cdk.CfnOutput(this, 'AwsAuthConfigMapYaml', {
      value: JSON.stringify(awsAuthManifest, null, 2),
      description: 'aws-auth ConfigMap YAML (apply with kubectl)',
    });

    new cdk.CfnOutput(this, 'ApplyCommand', {
      value: `kubectl apply -f aws-auth-configmap.yaml`,
      description: 'Command to apply aws-auth ConfigMap',
    });

    // Output the ConfigMap in a format ready to save
    new cdk.CfnOutput(this, 'Instructions', {
      value: 'Save the ConfigMap YAML to aws-auth-configmap.yaml and apply it using kubectl after updating kubeconfig',
    });
  }

  private createAwsAuthProvider(handlerCode: string, role: iam.Role): cdk.custom_resources.Provider {
    const onEvent = new cdk.aws_lambda.Function(this, 'AwsAuthHandlerFunction', {
      runtime: cdk.aws_lambda.Runtime.PYTHON_3_12,
      handler: 'index.handler',
      code: cdk.aws_lambda.Code.fromInline(handlerCode),
      timeout: cdk.Duration.minutes(5),
      role: role,
    });

    return new cdk.custom_resources.Provider(this, 'AwsAuthProvider', {
      onEventHandler: onEvent,
    });
  }
}
