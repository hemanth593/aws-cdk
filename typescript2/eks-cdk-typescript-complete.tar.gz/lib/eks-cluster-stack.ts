import * as cdk from 'aws-cdk-lib';
import * as eks from 'aws-cdk-lib/aws-eks';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as kms from 'aws-cdk-lib/aws-kms';
import { Construct } from 'constructs';
import { EksVpcCdkStack } from './eks-vpc-cdk-stack';
import { EksKmsKeyStack } from './eks-kms-key-stack';

export class EksClusterStack extends cdk.Stack {
  public readonly cluster: eks.CfnCluster;
  public readonly primarySecurityGroupId: string;

  constructor(
    scope: Construct,
    id: string,
    vpcStack: EksVpcCdkStack,
    kmsKeyStack: EksKmsKeyStack,
    props?: cdk.StackProps
  ) {
    super(scope, id, props);

    // Retrieve VPC and subnet information from the passed vpc_stack
    const vpcCfn = vpcStack.vpc;
    const publicSubnets = vpcStack.publicSubnets;
    const privateSubnets = vpcStack.privateSubnets;

    // Import the VPC as an L2 construct for use with SecurityGroup
    const vpc = ec2.Vpc.fromVpcAttributes(this, 'ImportedVpc', {
      vpcId: vpcCfn.ref,
      availabilityZones: ['us-east-1a', 'us-east-1b', 'us-east-1c'],
      vpcCidrBlock: '192.168.0.0/16',
    });

    // 1. Create EKS cluster security group (Additional Security Group)
    const clusterSg = new ec2.SecurityGroup(this, 'EksClusterSecurityGroup', {
      vpc: vpc,
      securityGroupName: 'prod-sre-cluster-sg',
      description: 'Security group for EKS cluster control plane',
      allowAllOutbound: true,
    });

    // Add appropriate security group rules for EKS
    clusterSg.addIngressRule(
      ec2.Peer.ipv4('0.0.0.0/0'),
      ec2.Port.tcp(80),
      'Allow HTTP access to cluster'
    );
    clusterSg.addIngressRule(
      ec2.Peer.ipv4('0.0.0.0/0'),
      ec2.Port.tcp(3306),
      'Allow MySQL access to cluster'
    );

    // Get the EKS Cluster Role ARN
    const eksClusterRoleName = 'prod-sre-eks-cluster-role';
    const eksClusterRoleArn = `arn:${cdk.Stack.of(this).partition}:iam::${
      cdk.Stack.of(this).account
    }:role/${eksClusterRoleName}`;

    // Look up the IAM Role using the constructed ARN
    const eksClusterRole = iam.Role.fromRoleArn(
      this,
      'EksClusterRoleLookup',
      eksClusterRoleArn,
      {
        mutable: false,
      }
    );

    // 2. Create EKS Cluster with KMS encryption
    this.cluster = new eks.CfnCluster(this, 'ProdSreEksCluster', {
      name: 'prod-eks-sre-cluster',
      roleArn: eksClusterRole.roleArn,
      version: '1.33',
      resourcesVpcConfig: {
        subnetIds: [...publicSubnets, ...privateSubnets].map((s) => s.ref),
        securityGroupIds: [clusterSg.securityGroupId],
        endpointPublicAccess: true,
        endpointPrivateAccess: true,
        publicAccessCidrs: ['0.0.0.0/0'],
      },
      kubernetesNetworkConfig: {
        ipFamily: 'ipv4',
        serviceIpv4Cidr: '10.100.0.0/16',
      },
      // Enable envelope encryption with KMS
      encryptionConfig: [
        {
          provider: {
            keyArn: kmsKeyStack.kmsKey.keyArn,
          },
          resources: ['secrets'],
        },
      ],
      // Enable control plane logging
      logging: {
        clusterLogging: {
          enabledTypes: [
            { type: 'api' },
            { type: 'audit' },
            { type: 'authenticator' },
            { type: 'controllerManager' },
            { type: 'scheduler' },
          ],
        },
      },
    });

    // Store the primary security group ID
    this.primarySecurityGroupId = this.cluster.attrClusterSecurityGroupId;

    // Output the Cluster Name and ARN
    new cdk.CfnOutput(this, 'EksClusterName', {
      value: this.cluster.name!,
    });
    new cdk.CfnOutput(this, 'EksClusterArn', {
      value: this.cluster.attrArn,
    });

    // Output the PRIMARY Security Group
    new cdk.CfnOutput(this, 'EksClusterPrimarySecurityGroup', {
      value: this.cluster.attrClusterSecurityGroupId,
      description: 'Primary security group automatically created by EKS for the cluster',
    });

    // Output the Additional Security Group
    new cdk.CfnOutput(this, 'EksClusterAdditionalSecurityGroup', {
      value: clusterSg.securityGroupId,
      description: 'Additional security group we created and attached to the cluster',
    });
  }
}
