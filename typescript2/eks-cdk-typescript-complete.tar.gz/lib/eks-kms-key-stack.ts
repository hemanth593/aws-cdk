import * as cdk from 'aws-cdk-lib';
import * as kms from 'aws-cdk-lib/aws-kms';
import * as iam from 'aws-cdk-lib/aws-iam';
import { Construct } from 'constructs';

export class EksKmsKeyStack extends cdk.Stack {
  public readonly kmsKey: kms.Key;

  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const adminRoleArn = 'arn:aws:iam::575108957879:role/devops-admins';

    // Create KMS key for EKS envelope encryption
    this.kmsKey = new kms.Key(this, 'EksKmsKey', {
      description: 'KMS key for EKS cluster envelope encryption',
      enableKeyRotation: true,
      alias: 'alias/eks-prod-sre-cluster',
      removalPolicy: cdk.RemovalPolicy.RETAIN, // Retain key on stack deletion for safety
    });

    // Import the admin role
    const adminRole = iam.Role.fromRoleArn(
      this,
      'AdminRole',
      adminRoleArn
    );

    // Grant admin role full access to the KMS key
    this.kmsKey.grantAdmin(adminRole);

    // Add key policy to allow EKS service to use the key
    this.kmsKey.addToResourcePolicy(
      new iam.PolicyStatement({
        sid: 'Allow EKS service to use the key',
        effect: iam.Effect.ALLOW,
        principals: [
          new iam.ServicePrincipal('eks.amazonaws.com'),
        ],
        actions: [
          'kms:Decrypt',
          'kms:DescribeKey',
          'kms:CreateGrant',
        ],
        resources: ['*'],
      })
    );

    // Add key policy for cluster role (will be used by EKS)
    this.kmsKey.addToResourcePolicy(
      new iam.PolicyStatement({
        sid: 'Allow cluster role to use the key',
        effect: iam.Effect.ALLOW,
        principals: [
          new iam.ArnPrincipal(`arn:${cdk.Stack.of(this).partition}:iam::${cdk.Stack.of(this).account}:role/prod-sre-eks-cluster-role`),
        ],
        actions: [
          'kms:Encrypt',
          'kms:Decrypt',
          'kms:ReEncrypt*',
          'kms:GenerateDataKey*',
          'kms:CreateGrant',
          'kms:DescribeKey',
        ],
        resources: ['*'],
      })
    );

    // Add key policy for node group role (for pods to decrypt secrets)
    this.kmsKey.addToResourcePolicy(
      new iam.PolicyStatement({
        sid: 'Allow node group role to use the key',
        effect: iam.Effect.ALLOW,
        principals: [
          new iam.ArnPrincipal(`arn:${cdk.Stack.of(this).partition}:iam::${cdk.Stack.of(this).account}:role/prod-sre-workernode-role`),
        ],
        actions: [
          'kms:Decrypt',
          'kms:DescribeKey',
        ],
        resources: ['*'],
      })
    );

    // Outputs
    new cdk.CfnOutput(this, 'KmsKeyId', {
      value: this.kmsKey.keyId,
      description: 'KMS Key ID for EKS envelope encryption',
    });

    new cdk.CfnOutput(this, 'KmsKeyArn', {
      value: this.kmsKey.keyArn,
      description: 'KMS Key ARN for EKS envelope encryption',
    });

    new cdk.CfnOutput(this, 'KmsKeyAlias', {
      value: 'alias/eks-prod-sre-cluster',
      description: 'KMS Key Alias',
    });
  }
}
